package com.company;

public class Customer {

  private static int money;
  private String login;
  private String password;

  public Customer(int money, String login, String password) {
    this.money = money;
    this.login = login;
    this.password = password;
  }

  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder("Customer{");
    sb.append("money=").append(money);
    sb.append(", login='").append(login).append('\'');
    sb.append(", password='").append(password).append('\'');
    sb.append('}');
    return sb.toString();
  }

  public static int getMoney() {
    return money;
  }

  public void setMoney(int money) {
    this.money = money;
  }

  public String getLogin() {
    return login;
  }

  public void setLogin(String login) {
    this.login = login;
  }

  public String getPassword() {
    return password;
  }

  public void setPassword(String password) {
    this.password = password;
  }
}
