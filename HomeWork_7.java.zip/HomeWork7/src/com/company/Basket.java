package com.company.Store;

import com.company.Product.Product;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class Basket implements Serializable {

  Map<Integer, Product> products = new HashMap<Integer, Product>();

  public Basket() {
  }

  public boolean add(int id, Product product) {
    if (product.isEmpty()) {
      return false;
    }
    if (products.containsKey(product.getId())) {
      Product old = products.get(product.getId());
      products.replace(product.getId(), old);
    } else {
      products.put(product.getId(), product);
    }
    return true;
  }

  public String toString() {
    StringBuilder sb = new StringBuilder("\n");
    int i = 1;
    for (Map.Entry<Integer, Product> entry : products.entrySet()) {
      Product value = entry.getValue();
      sb.append(i).append(". ")
          .append("ID ")
          .append(value.getId())
          .append(", ")
          .append(value.getName())
          .append(", price ")
          .append(value.getPrice())
          .append("$, дата выпуска ")
          .append(value.getDateOfIssue())
          .append("\n");
      i++;
    }
    return sb.toString();
  }


}

