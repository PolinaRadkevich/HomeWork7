package com.company;

import static com.company.CaseMenu.start;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {

  public static void main(String[] args) {

    Scanner str = new Scanner(System.in);
    System.out.println("Введите логин/пароль");

    if (str.hasNextLine()) {
      Map<String, Customer> customer = new HashMap<>();
      customer.put("Sonia/145_478po", new Customer(1500,"Sonia","145_478po"));
      customer.put("Roma/589ty145", new Customer(1400,"Roma", "589ty145"));
      customer.put("Viktoria/258_vic_258", new Customer(1000,"Viktoria", "258_vic_258"));
      customer.put("Olga/456ol789ga", new Customer(1700, "Olga", "456ol789ga"));
      for (int i = 0; i < 3; i++) {
        if (customer.containsKey(str.nextLine()) == true) {
          System.out.println("Добро пожаловать в наш магазин!!!");
              start();
              return;
            } else {
              System.out.println("Вы ввели не правильный логин/пароль!");
            }
          }
          System.out.println("Перезапустите программу и попробуйте снова!");


    }
  }
}












       /* Map<Integer, Product> product = new HashMap<>();
        Calendar calendar1 = Calendar.getInstance();
        calendar1.set(2020, Calendar.SEPTEMBER, 3);
        product.put(147369, new Product(147369,"Смартфон Apple iPhone X", ProductBrand.APPLE, 900, calendar1.getTime()));
        Calendar calendar2 = Calendar.getInstance();
        calendar2.set(2020, Calendar.OCTOBER, 10);
        product.put(258852,new Product(258852,"Смартфон Huawei Y6 Pro",ProductBrand.HUAWEI, 750,calendar2.getTime()));
        Calendar calendar3 = Calendar.getInstance();
        calendar3.set(2020, Calendar.JULY, 11);
        product.put(789123, new Product(789123,"Смартфон Lenovo Legion Pro",ProductBrand.LENOVO,950,calendar3.getTime()));
        Calendar calendar4 = Calendar.getInstance();
        calendar4.set(2021, Calendar.JANUARY, 11);
        product.put(456123, new Product(456123,"Смартфон LG Velvet",ProductBrand.LG,860,calendar4.getTime()));
        System.out.println(product);
    }*/




