package com.company.Product;

import com.company.Price;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;

public class Product implements Price, Serializable {

  public static int totalQuantity = 0;
  public static int totalPrice = 0;
  private String name;
  private int Id;
  private final ProductBrand productBrand;
  private int price;
  private final Date dateOfIssue;
  private final String DATE_PATTERN = "yyyy.MMMM.dd";
  private SimpleDateFormat simpleDateFormat = new SimpleDateFormat(DATE_PATTERN);


  public Product(int Id, String name, ProductBrand productBrand, int price, Date dateOfIssue) {
    this.Id = Id;
    this.name = name;
    this.productBrand = productBrand;
    this.price = price;
    this.dateOfIssue = dateOfIssue;
  }


  @Override
  public boolean equals(Object o) {
      if (this == o) {
          return true;
      }
      if (!(o instanceof Product)) {
          return false;
      }
    Product product = (Product) o;
    return getId() == product.getId() && getPrice() == product.getPrice() && Objects
        .equals(getName(), product.getName()) && productBrand == product.productBrand && Objects
        .equals(getDateOfIssue(), product.getDateOfIssue());
  }

  @Override
  public int hashCode() {
    return Objects.hash(getId(), getName(), productBrand, getPrice(), getDateOfIssue());
  }

  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder("Product");
    sb.append(", The name of this product is ").append(name).append(", ");
    sb.append("number ").append(Id);
    sb.append(", price ").append(price);
    sb.append(", manufactured ").append(dateOfIssue);
    sb.append(".\n Product Brand - ").append(productBrand);
      return sb.toString();
  }


  public boolean isEmpty() {
    return name.isEmpty() || getId() == 0;
  }

  public  int getId() {
    return Id;
  }

  public void setId(int id) {
    Id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public int getPrice() {
    return price;
  }

  public void setPrice(int price) {
    this.price = price;
  }

  public void getResult(int quantity) {
    this.totalQuantity += quantity ;
    this.totalPrice += (price * quantity);
  }


  public String getDateOfIssue() {
    final String DATE_PATTERN = "yyyy.MMMM.dd";
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy.MMMM.dd");
    String formattedDate = simpleDateFormat.format(dateOfIssue);
    return formattedDate;
  }

}
