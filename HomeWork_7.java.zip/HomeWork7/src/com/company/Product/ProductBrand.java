package com.company.Product;

public enum ProductBrand {

  HUAWEI("Huawei", "China", "Android"),
  APPLE("Apple", "USA", "Mac OS"),
  LG("Lg", "South Korea", "Android"),
  LENOVO("Lenovo", "China", "Android");

  private final String name;
  private final String country;
  private final String operatingSystem;


  ProductBrand(String name, String country, String operatingSystem) {
    this.name = name;
    this.country = country;
    this.operatingSystem = operatingSystem;

  }

  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder("The name of this product brand is ");
    sb.append(name);
    sb.append(", country brand ").append(country);
    sb.append(", Operating System").append(operatingSystem);
    sb.append("}");
    return sb.toString();
  }

  public String getName() {
    return name;
  }

  public String getCountry() {
    return country;
  }

  public String getOperatingSystem() {
    return operatingSystem;
  }


}


