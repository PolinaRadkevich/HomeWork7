package com.company;

import static com.company.Customer.*;

import com.company.Product.Product;
import com.company.Product.ProductBrand;
import com.company.Store;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class CaseMenu {

  private static Store<Product> productStore;
  private static List<Product> productList;
  static Basket basket = new Basket();


  private static void printMenu() {
    System.out.println("1. Для просмотра списка товаров с их ID для покупки введите 1");
    System.out.println("2. Для покупки товаров введите 2");
    System.out.println("3. Для просмотра списка купленных товаров с их ID введите 3");
    System.out.println("4. Для вывода информации о покупках в файл введите 4");
    System.out.println("5. Для выхода из приложения введите 5");
   }

  private static void initData() {
    Calendar calendar1 = Calendar.getInstance();
    calendar1.set(2020, Calendar.SEPTEMBER, 3);
    Product myProduct1 = new Product(1, "Смартфон Apple iPhone X", ProductBrand.APPLE, 900,
        calendar1.getTime());
    Calendar calendar2 = Calendar.getInstance();
    calendar2.set(2020, Calendar.OCTOBER, 10);
    Product myProduct2 = new Product(2, "Смартфон Huawei Y6 Pro", ProductBrand.HUAWEI, 750,
        calendar2.getTime());
    Calendar calendar3 = Calendar.getInstance();
    calendar3.set(2020, Calendar.JULY, 11);
    Product myProduct3 = new Product(3, "Смартфон Lenovo Legion Pro", ProductBrand.LENOVO, 950,
        calendar3.getTime());
    Calendar calendar4 = Calendar.getInstance();
    calendar4.set(2021, Calendar.JANUARY, 11);
    Product myProduct4 = new Product(4, "Смартфон LG Velvet", ProductBrand.LG, 860,
        calendar4.getTime());
    productStore = new Store<>("Product Store", (Product) myProduct1,
        (Product) myProduct2, (Product) myProduct3, (Product) myProduct4);
    productList = new ArrayList<>();
    productList.add(myProduct1);
    productList.add(myProduct2);
    productList.add(myProduct3);
    productList.add(myProduct4);
  }

  public static void start() {
    initData();
    Scanner scanner = new Scanner(System.in);
    int key;
    do {
      printMenu();
      System.out.print("Введите номер меню: ");
      key = scanner.nextInt();

      switch (key) {
        case 1:
          productStore.printProducts();
          break;
        case 2:
          System.out.println("Выберете продукт: ");
          for (int i = 1; i < productList.size() + 1; i++) {
            System.out.println(
                i + ". " + productList.get(i - 1).getName() + " - " + productList.get(i - 1)
                    .getPrice() + ";");
          }
          while (true) {
            System.out.println("Введите номер продукта: ");
            for (Product product : productList) {
              if (scanner.nextInt() == product.getId()) {
                productStore.purchase(product.getId(), Customer.getMoney());
                if (!basket.add(product.getId(), product))
                /*System.out.println("Товар " + product.getName() + ", цена " +product.getPrice());*/
                break;
              } else {
                String value = scanner.next();
                if (value.equalsIgnoreCase("end")) {
                  break;
                } else
                  System.out.println("Товара с таким id не существует");}}
              break;}
            case 3:
              String out = basket.toString();
              if(out.isEmpty())
                out = "\nКорзина пуста";
              System.out.printf("%s\n\n", out);
              break;
            case 4:
              try(BufferedWriter bw = new BufferedWriter(new FileWriter("product.txt")))
              {
                String text = basket.toString();
                bw.write(text);
              }
              catch(IOException ex){

                System.out.println(ex.getMessage());
              }
             break;
            case 5:
              System.out.println("Завершение программы...");
              break;
            default:
              System.out.println("Вы ввели неверное значение меню...\n");
          }
      }
      while (key != 5);
    }
  }


