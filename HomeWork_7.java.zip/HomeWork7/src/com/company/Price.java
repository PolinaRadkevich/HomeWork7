package com.company;

public interface Price {

  int getPrice();

  void setPrice(int price);

  static String getName() {
    return null;
  }

}
