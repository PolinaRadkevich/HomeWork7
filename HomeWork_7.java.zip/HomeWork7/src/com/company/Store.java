package com.company;

import java.lang.reflect.Array;


public class Store<T extends Price> {


  private String nameOfStore;
  private T[] tempArray;
  private T[] productsList;
  private int amountOfMoneyInCass = 100000;
  private int amountOfProduct;

  public Store(String nameOfStore, T... product){
    this.nameOfStore = nameOfStore;
    this.productsList = product;
    amountOfProduct = productsList.length;
  }

  public Store(String nameOfStore, int amountOfMoneyInCass, T... product){
    this.nameOfStore = nameOfStore;
    this.amountOfMoneyInCass = amountOfMoneyInCass;
    this.productsList = product;
    amountOfProduct = productsList.length;
  }


  public void purchase(int positionInList, int money) {
    if (positionInList - 1 < 0 || positionInList - 1 >= productsList.length) {
      System.out.println("There are no products under this number.");
    } else {
      Class<T> tClass = (Class<T>) productsList[positionInList - 1].getClass();
      if (money >= productsList[positionInList - 1].getPrice()) {
        int j = 0;
        createTempArray(tClass, productsList.length - 1);
        for (int i = 0; i < productsList.length; i++) {
          if (i == positionInList - 1) {
            continue;
          }
          tempArray[j] = productsList[i];
          j++;
        }
        amountOfMoneyInCass += productsList[positionInList - 1].getPrice();
        productsList = tempArray;
      } else {
        System.out.println("You are offering not enough money.");
      }
    }
  }

  public void createTempArray(Class<T> tClass, int length) {
    tempArray = (T[]) Array.newInstance(tClass, length);
  }

  public void printProducts() {
    if (amountOfProduct == 0) {
      System.out.println("There are no products in the store.");
    } else {
      for (int i = 0; i < productsList.length; i++) {
        int j = i + 1;
        System.out.println(j + ". " + productsList[i].getClass().getSimpleName() + ". " +
            productsList[i].toString() + "\nIt costs - " + productsList[i].getPrice());
      }
    }
  }

  public String getNameOfStore() {
    return nameOfStore;
  }

  public void setNameOfStore(String nameOfStore) {
    this.nameOfStore = nameOfStore;
  }

  private int getAmountOfProduct() {
    return amountOfProduct;
  }

  public double getAmountOfMoneyInCass() {
    return amountOfMoneyInCass;
  }

  public void setAmountOfMoneyInCass(int amountOfMoneyInCass) {
    this.amountOfMoneyInCass = amountOfMoneyInCass;
  }
}



